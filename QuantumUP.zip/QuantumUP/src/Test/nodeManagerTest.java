package Test;
import static org.mockito.Mockito.*;
import org.junit.Before;

import nodeUnit.View.NodeManager;

public class nodeManagerTest {

	
	NodeManager manager;
	@Before
	public void init() {
		manager = mock(NodeManager.class);
		
	}
}
